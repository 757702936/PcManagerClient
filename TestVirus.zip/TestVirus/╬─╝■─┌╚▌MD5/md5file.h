#pragma once
#pragma once
#ifndef MD5FILE_H
#define MD5FILE_H

#include <string>

std::string getFileMD5(const std::string& filename);

#endif